#pragma once

#define MAX_INDENT 20

#define BF_SIZE 123
/* BF_LIMBS = ceil(BF_SIZE/64) */
#define BF_LIMBS 2
#define BLOOM_NUM_HASHES 10
#define BLOOM_ENTRY_MAX 100

#define QUERY_LENGTH 20
#define N_GRAM_LENGTH 5
