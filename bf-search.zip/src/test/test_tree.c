#include "test_driver.h"

int
tree()
{
    test_setup();
    test_success();
    test_exit();
}