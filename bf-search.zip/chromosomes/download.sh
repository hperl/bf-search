#!/bin/bash

rsync -avzP rsync://hgdownload.cse.ucsc.edu/goldenPath/hg19/chromosomes/ .

echo -n "Unzipping "
for f in $(ls *.gz); do
  gunzip --force $f
  echo -n "."
done
echo " done."
